<template>
<div class="index">
    <div class="title">SDMS</div>
    <div class="label">A Document Managerment System for Students</div>
    <div class="btn">
        <el-button type="danger" @click="dialogFormVisible = true">Log in / Register</el-button>
    </div>
    <el-dialog title="Log in" :visible.sync="dialogFormVisible" width="400px" :close-on-click-modal="false">
        <el-form :model="form">
            <el-form-item label="user" :label-width="formLabelWidth">
                <el-input v-model="form.username" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="password" :label-width="formLabelWidth">
                <el-input v-model="form.password" autocomplete="off" type="password"></el-input>
            </el-form-item>
            <el-form-item label="check code" :label-width="formLabelWidth">
                <el-input v-model="form.checkcode" autocomplete="off"></el-input>
                <div v-html="svgData" @click="refreshCheckCode"></div>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="signIn">Log in</el-button>
            <el-button @click="tosignUp">Register</el-button>
        </div>
    </el-dialog>
    <el-dialog title="Register" :visible.sync="dialog2FormVisible" width="500px" :close-on-click-modal="false">
        <el-form :model="form">
            <el-form-item label="user name" :label-width="formLabelWidth">
                <el-input v-model="form.username" autocomplete="off" placeholder="Input an e-mail address" :disabled="emailDisabled">
                    <el-button slot="append" type="success" @click="sendVerifyCode" :disabled="emailDisabled">verify</el-button>
                </el-input>
            </el-form-item>
            <el-form-item label="verification code" :label-width="formLabelWidth">
                <el-input v-model="form.vercode" autocomplete="off" placeholder="">
                    <!-- <el-button slot="append" type="success"  @click="sendVerifyCode">verify</el-button> -->
                </el-input>
            </el-form-item>
            <el-form-item label="password" :label-width="formLabelWidth">
                <el-input v-model="form.password" autocomplete="off" type="password"></el-input>
            </el-form-item>
            <!-- <el-form-item label="e-mail" :label-width="formLabelWidth">
                <el-input v-model="form.password" autocomplete="off" type="password"></el-input>
        </el-form-item>-->
        </el-form>
        <div slot="footer" class="dialog-footer">
            <!-- <el-button type="primary" @click="signIn">Log in</el-button> -->
            <el-button @click="signUp">Register</el-button>
        </div>
    </el-dialog>
</div>
</template>

<script>
import CryptoJS from 'crypto-js';
export default {
    name: "index",
    data() {
        return {
            dialogFormVisible: false,
            dialog2FormVisible: false,
            form: {
                username: "",
                password: "",
                checkcode: "",
                vercode:""
            },
            formLabelWidth: "120px",
            emailDisabled: false,
            svgData: ''
        };
    },
    methods: {
        // 登录
        signIn() {
            this.dialogFormVisible = false;
            this.$http
                .post("/user/validate", {
                    username: this.form.username,
                    password: this.encrypt(this.form.password),
                    checkcode: this.form.checkcode
                })
                .then(res => {
                    if (res.data.flag === 0) {
                        this.$message.error(res.data.msg + "!!");
                        this.getCheckCode();
                    } else {
                        this.$message.success(res.data.msg);
                        sessionStorage.setItem("uid", res.data.uid);
                        sessionStorage.setItem("username", res.data.username);
                        this.hasNew();
                        //  跳转到其他页面
                        this.$router.push("tab-list");
                    }
                })
                .catch(err => {
                    console.log(err);
                });
        },

        async hasNew() {
            let res = await this.$http.get(`/share/new/${sessionStorage.uid}`);
            if (res.data.flag == 1) {
                sessionStorage.setItem("showBadge", 1);
            }
        },

        tosignUp() {
            this.dialogFormVisible = false;
            this.dialog2FormVisible = true;
        },
        sendVerifyCode() {
            let email = this.form.username;
            var reg = /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
            if (!reg.test(email)) {
                this.$message.error("Username should be an e-mail address!")
                return;
            }
            this.$http.post("/user/verify", {
                username: email
            }).then(res => {
                if (res.data.flag == 0) {
                    this.$message.error(res.data.info);
                } else {
                    this.$message.success(res.data.info);
                    this.emailDisabled = true;
                }
            })

        },
        //  注册
        signUp() {
            //this.dialogFormVisible = false;
            this.$http
                .post("/user/add", {
                    vercode:this.form.vercode,
                    username:this.form.username,
                    password:this.encrypt(this.form.password)
                })
                .then(res => {
                    if (res.data.flag === 0) {
                        this.$message.error(res.data.msg);
                    } else {
                        this.$message.success(res.data.msg);
                        setTimeout(() => {
                            this.dialog2FormVisible = false;
                            this.dialogFormVisible = true;
                        }, 2000)

                        //this.$router.push('tab-list')
                    }
                })
                .catch(err => {
                    console.log(err);
                });
        },
        getCheckCode() {
            this.$http.get('/user/checkcode').then(res => {
                this.svgData = res.data;
            })
        },
        refreshCheckCode() {
            this.getCheckCode();
        },

        /**
         * 加密
         */
        encrypt(word, keyStr) {
            keyStr = keyStr ? keyStr : "sdms123456SDMS654321";
            let key = CryptoJS.enc.Utf8.parse(keyStr);
            let srcs = CryptoJS.enc.Utf8.parse(word);
            let encrypted = CryptoJS.AES.encrypt(srcs, key, {
                mode: CryptoJS.mode.ECB,
                padding: CryptoJS.pad.Pkcs7
            });
            return encrypted.toString();

        },
    },
        mounted() {
            this.hasNew();
            this.getCheckCode();
        }
    }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped>
.index {
    margin-top: 140px;

    height: 700px;
    text-align: center;
    background: url("/static/bg.png") center no-repeat;
}

.title {
    padding-top: 20px;
    font-size: 80px;
    font-weight: bolder;
}

.label {
    font-size: 40px;
    margin-top: 30px;
    margin-bottom: 20px;
    font-weight: bold;
}

.btn {
    margin-top: 10px;
}

.dialog-footer {
    text-align: center;
}
</style>
